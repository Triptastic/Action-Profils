-------------------------------
-- Taste TMW Action Rotation --
-------------------------------
local TMW                                       = TMW
local CNDT                                      = TMW.CNDT
local Env                                       = CNDT.Env
local Action                                    = Action
local Listener                                  = Action.Listener
local Create                                    = Create
local GetToggle                                 = Action.GetToggle
local SetToggle                                 = Action.SetToggle
local GetGCD                                    = Action.GetGCD
local GetCurrentGCD                             = Action.GetCurrentGCD
local GetPing                                   = Action.GetPing
local ShouldStop                                = Action.ShouldStop
local BurstIsON                                 = Action.BurstIsON
local AuraIsValid                               = Action.AuraIsValid
local InterruptIsValid                          = Action.InterruptIsValid
local FrameHasSpell                             = Action.FrameHasSpell
local Azerite                                   = LibStub("AzeriteTraits")
local Utils                                     = Action.Utils
local TeamCache                                 = Action.TeamCache
local EnemyTeam                                 = Action.EnemyTeam
local FriendlyTeam                              = Action.FriendlyTeam
local LoC                                       = Action.LossOfControl
local Player                                    = Action.Player
local MultiUnits                                = Action.MultiUnits
local UnitCooldown                              = Action.UnitCooldown
local Unit                                      = Action.Unit
local IsUnitEnemy                               = Action.IsUnitEnemy
local IsUnitFriendly                            = Action.IsUnitFriendly
local HealingEngine                             = Action.HealingEngine
local ActiveUnitPlates                          = MultiUnits:GetActiveUnitPlates()
local TeamCacheFriendly                         = TeamCache.Friendly
local TeamCacheFriendlyIndexToPLAYERs           = TeamCacheFriendly.IndexToPLAYERs
local IsIndoors, UnitIsUnit                     = IsIndoors, UnitIsUnit
local TR                                        = Action.TasteRotation
local Pet                                       = LibStub("PetLibrary")
local next, pairs, type, print                  = next, pairs, type, print
local math_floor                                = math.floor
local math_ceil                                 = math.ceil
local tinsert                                   = table.insert
local select, unpack, table                     = select, unpack, table
local CombatLogGetCurrentEventInfo              = _G.CombatLogGetCurrentEventInfo
local UnitGUID, UnitIsUnit, UnitDamage, UnitAttackSpeed, UnitAttackPower = UnitGUID, UnitIsUnit, UnitDamage, UnitAttackSpeed, UnitAttackPower
local _G, setmetatable, select, math            = _G, setmetatable, select, math
local huge                                      = math.huge
local UIParent                                  = _G.UIParent
local CreateFrame                               = _G.CreateFrame
local wipe                                      = _G.wipe
local IsUsableSpell                             = IsUsableSpell
local UnitPowerType                             = UnitPowerType

--- ============================ CONTENT =========================== ---
--- ======================= SPELLS DECLARATION ===================== ---

Action[ACTION_CONST_SHAMAN_ENHANCEMENT] = {
    -- Racial
    ArcaneTorrent                          = Create({ Type = "Spell", ID = 50613     }),
    BloodFury                              = Create({ Type = "Spell", ID = 20572      }),
    Fireblood                              = Create({ Type = "Spell", ID = 265221     }),
    AncestralCall                          = Create({ Type = "Spell", ID = 274738     }),
    Berserking                             = Create({ Type = "Spell", ID = 26297    }),
    ArcanePulse                            = Create({ Type = "Spell", ID = 260364    }),
    QuakingPalm                            = Create({ Type = "Spell", ID = 107079     }),
    Haymaker                               = Create({ Type = "Spell", ID = 287712     }), 
    WarStomp                               = Create({ Type = "Spell", ID = 20549     }),
    BullRush                               = Create({ Type = "Spell", ID = 255654     }),  
    GiftofNaaru                            = Create({ Type = "Spell", ID = 59544    }),
    Shadowmeld                             = Create({ Type = "Spell", ID = 58984    }), -- usable in Action Core 
    Stoneform                              = Create({ Type = "Spell", ID = 20594    }), 
    WilloftheForsaken                      = Create({ Type = "Spell", ID = 7744        }), -- not usable in APL but user can Queue it   
    EscapeArtist                           = Create({ Type = "Spell", ID = 20589    }), -- not usable in APL but user can Queue it
    EveryManforHimself                     = Create({ Type = "Spell", ID = 59752    }), -- not usable in APL but user can Queue it
    -- Generics
    WindfuryWeapon                         = Create({ Type = "Spell", ID =  }),
    FlametongueWeapon                      = Create({ Type = "Spell", ID =  }),
    LightningShield                        = Create({ Type = "Spell", ID = 192106 }),
    Stormkeeper                            = Create({ Type = "Spell", ID =  }),
    WindfuryTotem                          = Create({ Type = "Spell", ID =  }),
    CrashLightning                         = Create({ Type = "Spell", ID = 187874 }),
    ChainLightning                         = Create({ Type = "Spell", ID =  }),
    StormkeeperBuff                        = Create({ Type = "Spell", ID =  }),
    MaelstromWeaponBuff                    = Create({ Type = "Spell", ID =  }),
    ElementalBlast                         = Create({ Type = "Spell", ID =  }),
    FlameShock                             = Create({ Type = "Spell", ID =  }),
    FireNova                               = Create({ Type = "Spell", ID =  }),
    FlameShockDebuff                       = Create({ Type = "Spell", ID =  }),
    Stormstrike                            = Create({ Type = "Spell", ID = 17364 }),
    LavaLash                               = Create({ Type = "Spell", ID = 60103 }),
    HailstormBuff                          = Create({ Type = "Spell", ID =  }),
    FrostShock                             = Create({ Type = "Spell", ID =  }),
    Hailstorm                              = Create({ Type = "Spell", ID = 210853 }),
    IceStrike                              = Create({ Type = "Spell", ID =  }),
    WindfuryTotemBuff                      = Create({ Type = "Spell", ID =  }),
    LightningBolt                          = Create({ Type = "Spell", ID = 187837 }),
    HotHandBuff                            = Create({ Type = "Spell", ID = 215785 }),
    WindShear                              = Create({ Type = "Spell", ID = 57994 }),
    Windstrike                             = Create({ Type = "Spell", ID = 115356 }),
    HeartEssence                           = Create({ Type = "Spell", ID = 298554 }),
    BloodFury                              = Create({ Type = "Spell", ID = 20572 }),
    Ascendance                             = Create({ Type = "Spell", ID = 114051 }),
    AscendanceBuff                         = Create({ Type = "Spell", ID = 114051 }),
    Berserking                             = Create({ Type = "Spell", ID = 26297 }),
    Fireblood                              = Create({ Type = "Spell", ID = 265221 }),
    AncestralCall                          = Create({ Type = "Spell", ID = 274738 }),
    BagofTricks                            = Create({ Type = "Spell", ID =  }),
    FeralSpirit                            = Create({ Type = "Spell", ID = 51533 }),
    EarthenSpike                           = Create({ Type = "Spell", ID = 188089 }),
    Sundering                              = Create({ Type = "Spell", ID = 197214 })
    -- Trinkets
    TrinketTest                            = Create({ Type = "Trinket", ID = 122530, QueueForbidden = true }), 
    TrinketTest2                           = Create({ Type = "Trinket", ID = 159611, QueueForbidden = true }), 
    AzsharasFontofPower                    = Create({ Type = "Trinket", ID = 169314, QueueForbidden = true }), 
    PocketsizedComputationDevice           = Create({ Type = "Trinket", ID = 167555, QueueForbidden = true }), 
    RotcrustedVoodooDoll                   = Create({ Type = "Trinket", ID = 159624, QueueForbidden = true }), 
    ShiverVenomRelic                       = Create({ Type = "Trinket", ID = 168905, QueueForbidden = true }), 
    AquipotentNautilus                     = Create({ Type = "Trinket", ID = 169305, QueueForbidden = true }), 
    TidestormCodex                         = Create({ Type = "Trinket", ID = 165576, QueueForbidden = true }), 
    VialofStorms                           = Create({ Type = "Trinket", ID = 158224, QueueForbidden = true }), 
    -- Potions
    PotionofUnbridledFury                  = Create({ Type = "Potion", ID = 169299, QueueForbidden = true }), 
    BattlePotionOfAgility                  = Create({ Type = "Potion", ID = 163223, QueueForbidden = true }), 
    SuperiorBattlePotionOfAgility          = Create({ Type = "Potion", ID = 168489, QueueForbidden = true }), 
    PotionTest                             = Create({ Type = "Potion", ID = 142117, QueueForbidden = true }), 
    -- Trinkets
    GenericTrinket1                        = Create({ Type = "Trinket", ID = 114616, QueueForbidden = true }),
    GenericTrinket2                        = Create({ Type = "Trinket", ID = 114081, QueueForbidden = true }),
    TrinketTest                            = Create({ Type = "Trinket", ID = 122530, QueueForbidden = true }),
    TrinketTest2                           = Create({ Type = "Trinket", ID = 159611, QueueForbidden = true }), 
    AzsharasFontofPower                    = Create({ Type = "Trinket", ID = 169314, QueueForbidden = true }),
    PocketsizedComputationDevice           = Create({ Type = "Trinket", ID = 167555, QueueForbidden = true }),
    RotcrustedVoodooDoll                   = Create({ Type = "Trinket", ID = 159624, QueueForbidden = true }),
    ShiverVenomRelic                       = Create({ Type = "Trinket", ID = 168905, QueueForbidden = true }),
    AquipotentNautilus                     = Create({ Type = "Trinket", ID = 169305, QueueForbidden = true }),
    TidestormCodex                         = Create({ Type = "Trinket", ID = 165576, QueueForbidden = true }),
    VialofStorms                           = Create({ Type = "Trinket", ID = 158224, QueueForbidden = true }),
    GalecallersBoon                        = Create({ Type = "Trinket", ID = 159614, QueueForbidden = true }),
    InvocationOfYulon                      = Create({ Type = "Trinket", ID = 165568, QueueForbidden = true }),
    LustrousGoldenPlumage                  = Create({ Type = "Trinket", ID = 159617, QueueForbidden = true }),
    ComputationDevice                      = Create({ Type = "Trinket", ID = 167555, QueueForbidden = true }),
    VigorTrinket                           = Create({ Type = "Trinket", ID = 165572, QueueForbidden = true }),
    FontOfPower                            = Create({ Type = "Trinket", ID = 169314, QueueForbidden = true }),
    RazorCoral                             = Create({ Type = "Trinket", ID = 169311, QueueForbidden = true }),
    AshvanesRazorCoral                     = Create({ Type = "Trinket", ID = 169311, QueueForbidden = true }),
    -- Misc
    Channeling                             = Create({ Type = "Spell", ID = 209274, Hidden = true     }),	-- Show an icon during channeling
    TargetEnemy                            = Create({ Type = "Spell", ID = 44603, Hidden = true     }),	-- Change Target (Tab button)
    StopCast                               = Create({ Type = "Spell", ID = 61721, Hidden = true     }),		-- spell_magic_polymorphrabbit
    CyclotronicBlast                       = Create({ Type = "Spell", ID = 293491, Hidden = true}),
    ConcentratedFlameBurn                  = Create({ Type = "Spell", ID = 295368, Hidden = true}),
    RazorCoralDebuff                       = Create({ Type = "Spell", ID = 303568, Hidden = true     }),
    ConductiveInkDebuff                    = Create({ Type = "Spell", ID = 302565, Hidden = true     }),
};

-- To create essences use next code:
Action:CreateEssencesFor(ACTION_CONST_SHAMAN_ENHANCEMENT)  -- where PLAYERSPEC is Constance (example: ACTION_CONST_MONK_BM)
local A = setmetatable(Action[ACTION_CONST_SHAMAN_ENHANCEMENT], { __index = Action })





local function num(val)
    if val then return 1 else return 0 end
end

local function bool(val)
    return val ~= 0
end

------------------------------------------
------- ENHANCEMENT PRE APL SETUP --------
------------------------------------------

local Temp = {
    TotalAndPhys                            = {"TotalImun", "DamagePhysImun"},
	TotalAndCC                              = {"TotalImun", "CCTotalImun"},
    TotalAndPhysKick                        = {"TotalImun", "DamagePhysImun", "KickImun"},
    TotalAndPhysAndCC                       = {"TotalImun", "DamagePhysImun", "CCTotalImun"},
    TotalAndPhysAndStun                     = {"TotalImun", "DamagePhysImun", "StunImun"},
    TotalAndPhysAndCCAndStun                = {"TotalImun", "DamagePhysImun", "CCTotalImun", "StunImun"},
    TotalAndMag                             = {"TotalImun", "DamageMagicImun"},
	TotalAndMagKick                         = {"TotalImun", "DamageMagicImun", "KickImun"},
    DisablePhys                             = {"TotalImun", "DamagePhysImun", "Freedom", "CCTotalImun"},
    DisableMag                              = {"TotalImun", "DamageMagicImun", "Freedom", "CCTotalImun"},
}

local IsIndoors, UnitIsUnit = IsIndoors, UnitIsUnit
local player = "player"

local function IsSchoolFree()
	return LoC:IsMissed("SILENCE") and LoC:Get("SCHOOL_INTERRUPT", "SHADOW") == 0
end 

local function InRange(unit)
	-- @return boolean 
	return A.LavaLash:IsInRange(unit)
end 
InRange = A.MakeFunctionCachedDynamic(InRange)

local function GetByRange(count, range, isStrictlySuperior, isStrictlyInferior, isCheckEqual, isCheckCombat)
	-- @return boolean 
	local c = 0 
	
	if isStrictlySuperior == nil then
	    isStrictlySuperior = false
	end

	if isStrictlyInferior == nil then
	    isStrictlyInferior = false
	end	
	
	for unit in pairs(ActiveUnitPlates) do 
		if (not isCheckEqual or not UnitIsUnit("target", unit)) and (not isCheckCombat or Unit(unit):CombatTime() > 0) then 
			if InRange(unit) then 
				c = c + 1
			elseif range then 
				local r = Unit(unit):GetRange()
				if r > 0 and r <= range then 
					c = c + 1
				end 
			end 
			-- Strictly superior than >
			if isStrictlySuperior and not isStrictlyInferior then
			    if c > count then
				    return true
				end
			end
			
			-- Stryctly inferior <
			if isStrictlyInferior and not isStrictlySuperior then
			    if c < count then
			        return true
				end
			end
			
			-- Classic >=
			if not isStrictlyInferior and not isStrictlySuperior then
			    if c >= count then 
				    return true 
			    end 
			end
		end 
		
	end
	
end  
GetByRange = A.MakeFunctionCachedDynamic(GetByRange)

-- API - Tracker
-- Initialize Tracker 
Pet:AddTrackers(ACTION_CONST_SHAMAN_ENCHANCEMENT, { -- this template table is the same with what has this library already built-in, just for example
    [29264] = {
        name = "Spirit Wolves",
        duration = 15,
    },
})

-- Function to check for Infernal duration
local function SpiritWolvesTime()
    return Pet:GetRemainDuration(29264) or 0
end 
SpiritWolvesTime = A.MakeFunctionCachedStatic(SpiritWolvesTime)

local function ResonanceTotemTime()
    for index = 1, 4 do
        local _, totemName, startTime, duration = GetTotemInfo(index)
        if totemName == A.TotemMastery:Info() then
            return (floor(startTime + duration - TMW.time + 0.5)) or 0
        end
    end
    return 0
end
ResonanceTotemTime = A.MakeFunctionCachedStatic(ResonanceTotemTime)

-- [1] CC AntiFake Rotation
local function AntiFakeStun(unit) 
    return 
    A.IsUnitEnemy(unit) and  
    Unit(unit):GetRange() <= 20 and 
    Unit(unit):IsControlAble("incapacitate", 0) and 
    A.HexGreen:AbsentImun(unit, Temp.TotalAndPhysAndCCAndStun, true)          
end 
A[1] = function(icon)    
    if	A.HexGreen:IsReady(nil, nil, nil, true) and 
    (
        AntiFakeStun("mouseover") or 
        AntiFakeStun("target") or 
        (
            not A.IsUnitEnemy("mouseover") and 
            not A.IsUnitEnemy("target")
        )
    )
    then 
        return A.HexGreen:Show(icon)         
    end                                                                     
end

-- [2] Kick AntiFake Rotation
A[2] = function(icon)        
    local unit
    if A.IsUnitEnemy("mouseover") then 
        unit = "mouseover"
    elseif A.IsUnitEnemy("target") then 
        unit = "target"
    end 
    
    if unit then         
        local castLeft, _, _, _, notKickAble = Unit(unit):IsCastingRemains()
        if castLeft > 0 then 
            -- Pummel		
            if not notKickAble and A.WindShearGreen:IsReady(unit, nil, nil, true) and A.WindShearGreen:AbsentImun(unit, Temp.TotalAndPhysKick, true) then
                return A.WindShearGreen:Show(icon)                                                  
            end 
                        
            -- Racials 
            if A.QuakingPalm:IsRacialReadyP(unit, nil, nil, true) then 
                return A.QuakingPalm:Show(icon)
            end 
            
            if A.Haymaker:IsRacialReadyP(unit, nil, nil, true) then 
                return A.Haymaker:Show(icon)
            end 
            
            if A.WarStomp:IsRacialReadyP(unit, nil, nil, true) then 
                return A.WarStomp:Show(icon)
            end 
            
            if A.BullRush:IsRacialReadyP(unit, nil, nil, true) then 
                return A.BullRush:Show(icon)
            end                         
        end 
    end                                                                                 
end

-- Non GCD spell check
local function countInterruptGCD(unit)
    if not A.WindShear:IsReadyByPassCastGCD(unit) or not A.WindShear:AbsentImun(unit, Temp.TotalAndMagKick) then
	    return true
	end
end

-- Interrupts spells
local function Interrupts(unit)
    if A.GetToggle(2, "TasteInterruptList") and (IsInRaid() or A.InstanceInfo.KeyStone > 1) then
	    useKick, useCC, useRacial, notInterruptable, castRemainsTime, castDoneTime = Action.InterruptIsValid(unit, "TasteBFAContent", true, countInterruptGCD(unit))
	else
        useKick, useCC, useRacial, notInterruptable, castRemainsTime, castDoneTime = Action.InterruptIsValid(unit, nil, nil, countInterruptGCD(unit))
    end
        
	if castRemainsTime >= A.GetLatency() then
	    -- WindShear
        if useKick and A.WindShear:IsReady(unit) then 
	        -- Notification					
            Action.SendNotification("Wind Shear interrupting on " .. unit, A.WindShear.ID)
            return A.WindShear
        end 
	
        -- CapacitorTotem
        if useCC and Action.GetToggle(2, "UseCapacitorTotem") and A.WindShear:GetCooldown() > 0 and A.CapacitorTotem:IsReady(player) then 
			-- Notification					
            Action.SendNotification("Capacitor Totem interrupting", A.CapacitorTotem.ID)
            return A.CapacitorTotem
        end  
    
        -- Hex	
        if useCC and A.Hex:IsReady(unit) and A.Hex:AbsentImun(unit, Temp.TotalAndCC, true) and Unit(unit):IsControlAble("incapacitate", 0) then 
	        -- Notification					
            Action.SendNotification("Hex interrupting", A.Hex.ID)
            return A.Hex              
        end  
		    
   	    if useRacial and A.QuakingPalm:AutoRacial(unit) then 
   	        return A.QuakingPalm
   	    end 
    
   	    if useRacial and A.Haymaker:AutoRacial(unit) then 
            return A.Haymaker
   	    end 
    
   	    if useRacial and A.WarStomp:AutoRacial(unit) then 
            return A.WarStomp
   	    end 
    
   	    if useRacial and A.BullRush:AutoRacial(unit) then 
            return A.BullRush
   	    end 
    end
end

local function SelfDefensives()
    if Unit(player):CombatTime() == 0 then 
        return 
    end 
    
    local unit
    if A.IsUnitEnemy("mouseover") then 
        unit = "mouseover"
    elseif A.IsUnitEnemy("target") then 
        unit = "target"
    end      
    
    -- EarthShieldHP
    local EarthShield = Action.GetToggle(2, "EarthShieldHP")
    if     EarthShield >= 0 and A.EarthShield:IsReady(player) and  
    (
        (     -- Auto 
            EarthShield >= 100 and 
            (
                Unit(player):HasBuffsStacks(A.EarthShield.ID, true) <= 3 
                or A.IsInPvP and Unit(player):HasBuffsStacks(A.EarthShield.ID, true) <= 2
            ) 
        ) or 
        (    -- Custom
            EarthShield < 100 and 
            Unit(player):HasBuffs(A.EarthShield.ID, true) <= 5 and 
            Unit(player):HealthPercent() <= EarthShield
        )
    ) 
    then 
        return A.EarthShield
    end
    
    -- HealingSurgeHP
    local HealingSurge = Action.GetToggle(2, "HealingSurgeHP")
    if     HealingSurge >= 0 and A.HealingSurge:IsReady(player) and Player:Maelstrom() > 20 and Unit("player"):CombatTime() > 2  and
    (
        (     -- Auto 
            HealingSurge >= 100 and 
            (
                -- HP lose per sec >= 10
                Unit(player):GetDMG() * 100 / Unit(player):HealthMax() >= 10 or 
                Unit(player):GetRealTimeDMG() >= Unit(player):HealthMax() * 0.10 or 
                -- TTD 
                Unit(player):TimeToDieX(25) < 5 or 
                (
                    A.IsInPvP and 
                    (
                        Unit(player):UseDeff() or 
                        (
                            Unit(player, 5):HasFlags() and 
                            Unit(player):GetRealTimeDMG() > 0 and 
                            Unit(player):IsFocused() 
                        )
                    )
                )
            ) and 
            Unit(player):HasBuffs("DeffBuffs", true) == 0
        ) or 
        (    -- Custom
            HealingSurge < 100 and 
            Unit(player):HealthPercent() <= HealingSurge
        )
    ) 
    then 
        return A.HealingSurge
    end
    
    -- Abyssal Healing Potion
    local AbyssalHealingPotion = Action.GetToggle(2, "AbyssalHealingPotionHP")
    if     AbyssalHealingPotion >= 0 and A.AbyssalHealingPotion:IsReady(player) and 
    (
        (     -- Auto 
            AbyssalHealingPotion >= 100 and 
            (
                -- HP lose per sec >= 25
                Unit(player):GetDMG() * 100 / Unit(player):HealthMax() >= 25 or 
                Unit(player):GetRealTimeDMG() >= Unit(player):HealthMax() * 0.25 or 
                -- TTD 
                Unit(player):TimeToDieX(25) < 5 or 
                (
                    A.IsInPvP and 
                    (
                        Unit(player):UseDeff() or 
                        (
                            Unit(player, 5):HasFlags() and 
                            Unit(player):GetRealTimeDMG() > 0 and 
                            Unit(player):IsFocused() 
                        )
                    )
                )
            ) and 
            Unit(player):HasBuffs("DeffBuffs", true) == 0
        ) or 
        (    -- Custom
            AbyssalHealingPotion < 100 and 
            Unit(player):HealthPercent() <= AbyssalHealingPotion
        )
    ) 
    then 
        return A.AbyssalHealingPotion
    end  
    
    -- AstralShift
    local AstralShift = Action.GetToggle(2, "AstralShiftHP")
    if     AstralShift >= 0 and A.AstralShift:IsReady(player) and 
    (
        (     -- Auto 
            AstralShift >= 100 and 
            (
                -- HP lose per sec >= 20
                Unit(player):GetDMG() * 100 / Unit(player):HealthMax() >= 20 or 
                Unit(player):GetRealTimeDMG() >= Unit(player):HealthMax() * 0.20 or 
                -- TTD 
                Unit(player):TimeToDieX(25) < 5 or 
                (
                    A.IsInPvP and 
                    (
                        Unit(player):UseDeff() or 
                        (
                            Unit(player, 5):HasFlags() and 
                            Unit(player):GetRealTimeDMG() > 0 and 
                            Unit(player):IsFocused() 
                        )
                    )
                )
            ) and 
            Unit(player):HasBuffs("DeffBuffs", true) == 0
        ) or 
        (    -- Custom
            AstralShift < 100 and 
            Unit(player):HealthPercent() <= AstralShift
        )
    ) 
    then 
        return A.AstralShift
    end     
    -- Stoneform on self dispel (only PvE)
    if A.Stoneform:IsRacialReady(player, true) and not A.IsInPvP and A.AuraIsValid(player, "UseDispel", "Dispel") then 
        return A.Stoneform
    end 
end 
SelfDefensives = A.MakeFunctionCachedStatic(SelfDefensives)

local function EvaluateCycleFlameShock42(unit)
  return A.FireNova:IsSpellLearned()
end

local function EvaluateCycleFlameShock59(unit)
  return not Unit("player"):HasBuffs(A.HailstormBuff.ID, true)
end

local function EvaluateCycleFlameShock72(unit)
  return not ticking and true and not A.Hailstorm:IsSpellLearned()
end

local function EvaluateCycleFlameShock135(unit)
    return refreshable
end

--- ======= ACTION LISTS =======
-- [3] Single Rotation
A[3] = function(icon, isMulti)

    --------------------
    --- ROTATION VAR ---
    --------------------
    local isMoving = A.Player:IsMoving()
    local isMovingFor = A.Player:IsMovingTime()
    local inCombat = Unit(player):CombatTime() > 0
    local combatTime = Unit(player):CombatTime()
    local ShouldStop = Action.ShouldStop()
    local Pull = Action.BossMods_Pulling()
    local DBM = Action.GetToggle(1, "DBM")
    local HeartOfAzeroth = Action.GetToggle(1, "HeartOfAzeroth")
    local Racial = Action.GetToggle(1, "Racial")
    local Potion = Action.GetToggle(1, "Potion")

    ------------------------------------------------------
    ---------------- ENEMY UNIT ROTATION -----------------
    ------------------------------------------------------
    local function EnemyRotation(unit)

        --Precombat
        local function Precombat(unit)
        
            -- flask
            -- food
            -- augmentation
            -- windfury_weapon
            if A.WindfuryWeapon:IsReady(unit) then
                return A.WindfuryWeapon:Show(icon)
            end
            
            -- flametongue_weapon
            if A.FlametongueWeapon:IsReady(unit) then
                return A.FlametongueWeapon:Show(icon)
            end
            
            -- lightning_shield
            if A.LightningShield:IsReady(unit) then
                return A.LightningShield:Show(icon)
            end
            
            -- stormkeeper,if=talent.stormkeeper.enabled
            if A.Stormkeeper:IsReady(unit) and (A.Stormkeeper:IsSpellLearned()) then
                return A.Stormkeeper:Show(icon)
            end
            
            -- windfury_totem
            if A.WindfuryTotem:IsReady(unit) then
                return A.WindfuryTotem:Show(icon)
            end
            
            -- potion
            if A.PotionofSpectralAgility:IsReady(unit) and Potion then
                return A.PotionofSpectralAgility:Show(icon)
            end
            
            -- snapshot_stats
        end
        
        --Aoe
        local function Aoe(unit)
        
            -- crash_lightning
            if A.CrashLightning:IsReady(unit) then
                return A.CrashLightning:Show(icon)
            end
            
            -- chain_lightning,if=buff.stormkeeper.up&buff.maelstrom_weapon.stack>=5
            if A.ChainLightning:IsReady(unit) and (Unit("player"):HasBuffs(A.StormkeeperBuff.ID, true) and Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.ChainLightning:Show(icon)
            end
            
            -- elemental_blast,if=buff.maelstrom_weapon.stack>=5
            if A.ElementalBlast:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.ElementalBlast:Show(icon)
            end
            
            -- stormkeeper,if=buff.maelstrom_weapon.stack>=5
            if A.Stormkeeper:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.Stormkeeper:Show(icon)
            end
            
            -- chain_lightning,if=buff.maelstrom_weapon.stack=10
            if A.ChainLightning:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) == 10) then
                return A.ChainLightning:Show(icon)
            end
            
            -- flame_shock,target_if=refreshable,cycle_targets=1,if=talent.fire_nova.enabled
            if A.FlameShock:IsReady(unit) then
                if Action.Utils.CastTargetIf(A.FlameShock, 40, "min", EvaluateCycleFlameShock42) then
                    return A.FlameShock:Show(icon) 
                end
            end
            -- fire_nova,if=active_dot.flame_shock>=3
            if A.FireNova:IsReady(unit) and (A.FlameShockDebuff.ID, true:ActiveDot >= 3) then
                return A.FireNova:Show(icon)
            end
            
            -- stormstrike
            if A.Stormstrike:IsReady(unit) then
                return A.Stormstrike:Show(icon)
            end
            
            -- lava_lash
            if A.LavaLash:IsReady(unit) then
                return A.LavaLash:Show(icon)
            end
            
            -- flame_shock,target_if=refreshable,cycle_targets=1,if=!buff.hailstorm.up
            if A.FlameShock:IsReady(unit) then
                if Action.Utils.CastTargetIf(A.FlameShock, 40, "min", EvaluateCycleFlameShock59) then
                    return A.FlameShock:Show(icon) 
                end
            end
            -- frost_shock,if=buff.hailstorm.up
            if A.FrostShock:IsReady(unit) and (Unit("player"):HasBuffs(A.HailstormBuff.ID, true)) then
                return A.FrostShock:Show(icon)
            end
            
            -- flame_shock,target_if=refreshable,cycle_targets=1,if=!ticking&&!talent.hailstorm.enabled
            if A.FlameShock:IsReady(unit) then
                if Action.Utils.CastTargetIf(A.FlameShock, 40, "min", EvaluateCycleFlameShock72) then
                    return A.FlameShock:Show(icon) 
                end
            end
            -- frost_shock
            if A.FrostShock:IsReady(unit) then
                return A.FrostShock:Show(icon)
            end
            
            -- ice_strike
            if A.IceStrike:IsReady(unit) then
                return A.IceStrike:Show(icon)
            end
            
            -- chain_lightning,if=buff.maelstrom_weapon.stack>=5
            if A.ChainLightning:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.ChainLightning:Show(icon)
            end
            
            -- windfury_totem,if=buff.windfury_totem.remains<30
            if A.WindfuryTotem:IsReady(unit) and (Unit("player"):HasBuffs(A.WindfuryTotemBuff.ID, true) < 30) then
                return A.WindfuryTotem:Show(icon)
            end
            
        end
        
        --Single
        local function Single(unit)
        
            -- flame_shock,if=!ticking
            if A.FlameShock:IsReady(unit) and (not ticking) then
                return A.FlameShock:Show(icon)
            end
            
            -- frost_shock,if=buff.hailstorm.up
            if A.FrostShock:IsReady(unit) and (Unit("player"):HasBuffs(A.HailstormBuff.ID, true)) then
                return A.FrostShock:Show(icon)
            end
            
            -- lightning_bolt,if=buff.stormkeeper.up&buff.maelstrom_weapon.stack>=5
            if A.LightningBolt:IsReady(unit) and (Unit("player"):HasBuffs(A.StormkeeperBuff.ID, true) and Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.LightningBolt:Show(icon)
            end
            
            -- elemental_blast,if=buff.maelstrom_weapon.stack>=5
            if A.ElementalBlast:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.ElementalBlast:Show(icon)
            end
            
            -- lightning_bolt,if=buff.maelstrom_weapon.stack=10
            if A.LightningBolt:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) == 10) then
                return A.LightningBolt:Show(icon)
            end
            
            -- lava_lash,if=buff.hot_hand.up
            if A.LavaLash:IsReady(unit) and (Unit("player"):HasBuffs(A.HotHandBuff.ID, true)) then
                return A.LavaLash:Show(icon)
            end
            
            -- stormstrike
            if A.Stormstrike:IsReady(unit) then
                return A.Stormstrike:Show(icon)
            end
            
            -- stormkeeper,if=buff.maelstrom_weapon.stack>=5
            if A.Stormkeeper:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.Stormkeeper:Show(icon)
            end
            
            -- lava_lash
            if A.LavaLash:IsReady(unit) then
                return A.LavaLash:Show(icon)
            end
            
            -- crash_lightning
            if A.CrashLightning:IsReady(unit) then
                return A.CrashLightning:Show(icon)
            end
            
            -- flame_shock,target_if=refreshable
            if A.FlameShock:IsReady(unit) then
                if Action.Utils.CastTargetIf(A.FlameShock, 40, "min", EvaluateCycleFlameShock135) then
                    return A.FlameShock:Show(icon) 
                end
            end
            -- frost_shock
            if A.FrostShock:IsReady(unit) then
                return A.FrostShock:Show(icon)
            end
            
            -- ice_strike
            if A.IceStrike:IsReady(unit) then
                return A.IceStrike:Show(icon)
            end
            
            -- fire_nova,if=active_dot.flame_shock
            if A.FireNova:IsReady(unit) and (A.FlameShockDebuff.ID, true:ActiveDot) then
                return A.FireNova:Show(icon)
            end
            
            -- lightning_bolt,if=buff.maelstrom_weapon.stack>=5
            if A.LightningBolt:IsReady(unit) and (Unit("player"):HasBuffsStacks(A.MaelstromWeaponBuff.ID, true) >= 5) then
                return A.LightningBolt:Show(icon)
            end
            
            -- windfury_totem,if=buff.windfury_totem.remains<30
            if A.WindfuryTotem:IsReady(unit) and (Unit("player"):HasBuffs(A.WindfuryTotemBuff.ID, true) < 30) then
                return A.WindfuryTotem:Show(icon)
            end
            
        end
        
        
        -- call precombat
        if Precombat(unit) and not inCombat and Unit(unit):IsExists() and unit ~= "mouseover" then 
            return true
        end

        -- In Combat
        if inCombat and Unit(unit):IsExists() then

                    -- bloodlust
            -- potion,if=expected_combat_length-time<60
            if A.PotionofSpectralAgility:IsReady(unit) and Potion and (expected_combat_length - Unit("player"):CombatTime() < 60) then
                return A.PotionofSpectralAgility:Show(icon)
            end
            
            -- wind_shear
            if A.WindShear:IsReady(unit) and Action.GetToggle.InterruptEnabled then
                return A.WindShear:Show(icon)
            end
            
            -- auto_attack
            -- windstrike
            if A.Windstrike:IsReady(unit) then
                return A.Windstrike:Show(icon)
            end
            
            -- heart_essence
            if A.HeartEssence:IsReady(unit) then
                return A.HeartEssence:Show(icon)
            end
            
            -- blood_fury,if=!talent.ascendance.enabled|buff.ascendance.up|cooldown.ascendance.remains>50
            if A.BloodFury:AutoRacial(unit) and Racial and A.BurstIsON(unit) and (not A.Ascendance:IsSpellLearned() or Unit("player"):HasBuffs(A.AscendanceBuff.ID, true) or A.Ascendance:GetCooldown() > 50) then
                return A.BloodFury:Show(icon)
            end
            
            -- berserking,if=!talent.ascendance.enabled|buff.ascendance.up
            if A.Berserking:AutoRacial(unit) and Racial and A.BurstIsON(unit) and (not A.Ascendance:IsSpellLearned() or Unit("player"):HasBuffs(A.AscendanceBuff.ID, true)) then
                return A.Berserking:Show(icon)
            end
            
            -- fireblood,if=!talent.ascendance.enabled|buff.ascendance.up|cooldown.ascendance.remains>50
            if A.Fireblood:AutoRacial(unit) and Racial and A.BurstIsON(unit) and (not A.Ascendance:IsSpellLearned() or Unit("player"):HasBuffs(A.AscendanceBuff.ID, true) or A.Ascendance:GetCooldown() > 50) then
                return A.Fireblood:Show(icon)
            end
            
            -- ancestral_call,if=!talent.ascendance.enabled|buff.ascendance.up|cooldown.ascendance.remains>50
            if A.AncestralCall:AutoRacial(unit) and Racial and A.BurstIsON(unit) and (not A.Ascendance:IsSpellLearned() or Unit("player"):HasBuffs(A.AscendanceBuff.ID, true) or A.Ascendance:GetCooldown() > 50) then
                return A.AncestralCall:Show(icon)
            end
            
            -- bag_of_tricks,if=!talent.ascendance.enabled|!buff.ascendance.up
            if A.BagofTricks:IsReady(unit) and (not A.Ascendance:IsSpellLearned() or not Unit("player"):HasBuffs(A.AscendanceBuff.ID, true)) then
                return A.BagofTricks:Show(icon)
            end
            
            -- feral_spirit
            if A.FeralSpirit:IsReady(unit) then
                return A.FeralSpirit:Show(icon)
            end
            
            -- earth_elemental
            -- earthen_spike
            if A.EarthenSpike:IsReady(unit) then
                return A.EarthenSpike:Show(icon)
            end
            
            -- sundering
            if A.Sundering:IsReady(unit) then
                return A.Sundering:Show(icon)
            end
            
            -- ascendance
            if A.Ascendance:IsReady(unit) then
                return A.Ascendance:Show(icon)
            end
            
            -- call_action_list,name=single,if=active_enemies=1
            if (MultiUnits:GetByRangeInCombat(40, 5, 10) == 1) then
                if Single(unit) then
                    return true
                end
            end
            
            -- call_action_list,name=aoe,if=active_enemies>1
            if (MultiUnits:GetByRangeInCombat(40, 5, 10) > 1) then
                if Aoe(unit) then
                    return true
                end
            end
            
        end
    end

    -- End on EnemyRotation()

    -- Defensive
    --local SelfDefensive = SelfDefensives()
    if SelfDefensive then 
        return SelfDefensive:Show(icon)
    end 

    -- Mouseover
    if A.IsUnitEnemy("mouseover") then
        unit = "mouseover"
        if EnemyRotation(unit) then 
            return true 
        end 
    end 

    -- Target  
    if A.IsUnitEnemy("target") then 
        unit = "target"
        if EnemyRotation(unit) then 
            return true
        end 

    end
end
-- Finished

-- [4] AoE Rotation
A[4] = function(icon)
    return A[3](icon, true)
end
 -- [5] Trinket Rotation
-- No specialization trinket actions 
-- Passive 
--[[local function FreezingTrapUsedByEnemy()
    if     UnitCooldown:GetCooldown("arena", 3355) > UnitCooldown:GetMaxDuration("arena", 3355) - 2 and
    UnitCooldown:IsSpellInFly("arena", 3355) and 
    Unit("player"):GetDR("incapacitate") >= 50 
    then 
        local Caster = UnitCooldown:GetUnitID("arena", 3355)
        if Caster and Unit(Caster):GetRange() <= 40 then 
            return true 
        end 
    end 
end 
local function ArenaRotation(icon, unit)
    if A.IsInPvP and (A.Zone == "pvp" or A.Zone == "arena") and not Player:IsStealthed() and not Player:IsMounted() then
        -- Note: "arena1" is just identification of meta 6
        if (unit == "arena1" or unit == "arena2" or unit == "arena3") then 
            -- Reflect Casting BreakAble CC
            if A.NetherWard:IsReady() and A.NetherWard:IsSpellLearned() and Action.ShouldReflect(EnemyTeam()) and EnemyTeam():IsCastingBreakAble(0.25) then 
                return A.NetherWard:Show(icon)
            end 
        end
    end 
end 
local function PartyRotation(unit)
    if (unit == "party1" and not A.GetToggle(2, "PartyUnits")[1]) or (unit == "party2" and not A.GetToggle(2, "PartyUnits")[2]) then 
        return false 
    end

  	-- SingeMagic
    if A.SingeMagic:IsCastable() and A.SingeMagic:AbsentImun(unit, Temp.TotalAndMag) and IsSchoolFree() and Action.AuraIsValid(unit, "UseDispel", "Magic") and not Unit(unit):InLOS() then
        return A.SingeMagic:Show(icon)
    end
end 

A[6] = function(icon)
    return ArenaRotation(icon, "arena1")
end

A[7] = function(icon)
    local Party = PartyRotation("party1") 
    if Party then 
        return Party:Show(icon)
    end 
    return ArenaRotation(icon, "arena2")
end

A[8] = function(icon)
    local Party = PartyRotation("party2") 
    if Party then 
        return Party:Show(icon)
    end     
    return ArenaRotation(icon, "arena3")
end]]--

